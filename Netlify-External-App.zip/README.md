# External App that works for auth0 action redirection
Check code for redirection at https://auth0.com/docs/customize/actions/flows-and-triggers/login-flow/redirect-with-actions

App meant to run as a netlify serverless site, based on templte from https://github.com/netlify/explorers-up-and-running-with-serverless-functions
